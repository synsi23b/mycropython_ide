metadata(description="Lightweight MQTT client for MicroPython.", version="1.3.4")

# Originally written by Paul Sokolovsky.

package("umqtt")
