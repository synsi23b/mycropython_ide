metadata(
    version="0.1",
    description="Provides an asynchronous REPL that can run concurrently with an asyncio, also allowing await expressions.",
)

module("aiorepl.py")
