metadata(version="0.2.0")

package(
    "aioble",
    files=(
        "__init__.py",
        "core.py",
        "device.py",
    ),
    base_path="../aioble",
)
