metadata(description="Make and parse DNS packets (Sans I/O approach).", version="0.1")

# Originally written by Paul Sokolovsky.

module("udnspkt.py")
