module("webrepl.py", opt=3)
module("webrepl_setup.py", opt=3)
