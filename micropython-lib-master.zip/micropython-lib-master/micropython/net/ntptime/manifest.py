module("ntptime.py", opt=3)
