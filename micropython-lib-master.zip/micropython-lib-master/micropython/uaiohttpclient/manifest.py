metadata(description="HTTP client module for MicroPython uasyncio module", version="0.5.1")

# Originally written by Paul Sokolovsky.

module("uaiohttpclient.py")
