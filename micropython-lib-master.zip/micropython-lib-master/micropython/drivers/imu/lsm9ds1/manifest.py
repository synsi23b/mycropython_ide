module("lsm9ds1.py", opt=3)
