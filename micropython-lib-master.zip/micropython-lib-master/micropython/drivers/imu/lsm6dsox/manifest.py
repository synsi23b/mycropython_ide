module("lsm6dsox.py", opt=3)
