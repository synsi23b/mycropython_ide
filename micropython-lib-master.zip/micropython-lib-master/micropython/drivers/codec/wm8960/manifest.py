module("wm8960.py", opt=3)
