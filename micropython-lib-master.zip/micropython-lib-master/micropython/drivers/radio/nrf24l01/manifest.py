module("nrf24l01.py", opt=3)
