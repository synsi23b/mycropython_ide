module("neopixel.py", opt=3)
