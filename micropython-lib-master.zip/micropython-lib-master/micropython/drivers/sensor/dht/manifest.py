module("dht.py", opt=3)
