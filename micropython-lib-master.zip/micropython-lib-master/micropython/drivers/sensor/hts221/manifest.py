module("hts221.py", opt=3)
