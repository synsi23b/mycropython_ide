require("onewire")
module("ds18x20.py", opt=3)
