metadata(version="0.0.3")

module("__future__.py")
