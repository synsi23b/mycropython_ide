metadata(version="0.3")

# Originally written by Paul Sokolovsky.

require("collections")
package("collections")
