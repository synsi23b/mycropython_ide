metadata(version="0.6.0")

module("fnmatch.py")
