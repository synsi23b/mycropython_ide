metadata(version="0.5.1")

require("binascii")
require("os-path")

module("uu.py")
