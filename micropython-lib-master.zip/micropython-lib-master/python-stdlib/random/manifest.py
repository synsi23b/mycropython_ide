metadata(version="0.2")

module("random.py")
