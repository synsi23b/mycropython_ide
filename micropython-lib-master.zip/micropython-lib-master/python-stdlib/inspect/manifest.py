metadata(version="0.1.2")

module("inspect.py")
