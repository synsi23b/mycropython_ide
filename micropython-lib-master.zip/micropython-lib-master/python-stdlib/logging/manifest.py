metadata(version="0.3")

module("logging.py")
