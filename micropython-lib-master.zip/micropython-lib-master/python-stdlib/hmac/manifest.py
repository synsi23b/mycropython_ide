metadata(version="3.4.2-3")

module("hmac.py")
