metadata(version="0.0.7")

module("functools.py")
