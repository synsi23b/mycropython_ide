metadata(version="0.1.1")

module("string.py")
