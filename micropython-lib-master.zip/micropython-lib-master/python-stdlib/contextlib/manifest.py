metadata(description="Port of contextlib for micropython", version="3.4.2-4")

require("ucontextlib")
require("collections")

module("contextlib.py")
