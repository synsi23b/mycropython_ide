metadata(version="3.4.2-1")

module("textwrap.py")
