metadata(version="0.1.4")

# Originally written by Paul Sokolovsky.

require("os")
package("os")
