metadata(version="0.1.1")

require("pkg_resources")

module("pkgutil.py")
