metadata(version="0.1")

module("io.py")
