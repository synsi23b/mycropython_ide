metadata(version="0.5.1")

module("stat.py")
