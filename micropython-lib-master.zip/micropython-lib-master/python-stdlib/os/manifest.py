metadata(version="0.6")

# Originally written by Paul Sokolovsky.

package("os")
