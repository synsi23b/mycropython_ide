# Module that is used in both test_isolated_1.py and test_isolated_2.py.
# The module should be clean reloaded for each.

state = None
