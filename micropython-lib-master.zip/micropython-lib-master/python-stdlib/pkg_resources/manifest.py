metadata(version="0.2.1")

module("pkg_resources.py")
