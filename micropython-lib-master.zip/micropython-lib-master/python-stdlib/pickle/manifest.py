metadata(version="0.1")

module("pickle.py")
