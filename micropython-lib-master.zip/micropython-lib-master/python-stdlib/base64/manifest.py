metadata(version="3.3.3-4")

require("binascii")
require("struct")

module("base64.py")
