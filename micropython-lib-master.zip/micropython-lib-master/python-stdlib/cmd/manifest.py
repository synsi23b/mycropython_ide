metadata(version="3.4.0-2")

module("cmd.py")
