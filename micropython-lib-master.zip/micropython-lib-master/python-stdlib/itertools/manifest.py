metadata(version="0.2.3")

module("itertools.py")
