metadata(version="0.9.3")

module("heapq.py")
