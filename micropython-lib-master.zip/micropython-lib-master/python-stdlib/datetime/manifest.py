metadata(version="4.0.0")

# Originally written by Lorenzo Cappelletti.

module("datetime.py")
