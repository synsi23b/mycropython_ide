metadata(version="0.0.5")

module("shutil.py")
