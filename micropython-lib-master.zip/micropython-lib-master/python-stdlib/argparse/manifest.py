metadata(version="0.4")

# Originally written by Damien George.

module("argparse.py")
