metadata(version="0.7.0")

module("urequests.py")
