metadata(version="0.1")

require("hmac")

module("jwt.py")
