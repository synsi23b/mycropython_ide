metadata(version="0.1")

# Originally written by Riccardo Magliocchetti.

require("ffilib", unix_ffi=True)

module("pwd.py")
