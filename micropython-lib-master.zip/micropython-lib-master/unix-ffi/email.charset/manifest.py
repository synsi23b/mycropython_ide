metadata(version="0.5.1")

require("functools")
require("email.encoders", unix_ffi=True)
require("email.errors", unix_ffi=True)

package("email")
