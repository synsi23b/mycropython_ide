metadata(version="0.6")

# Originally written by Paul Sokolovsky.

require("ffilib", unix_ffi=True)
require("errno")
require("stat")

package("os")
