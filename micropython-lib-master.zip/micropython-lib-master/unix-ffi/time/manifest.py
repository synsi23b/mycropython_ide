metadata(version="0.5")

require("ffilib", unix_ffi=True)

module("time.py")
