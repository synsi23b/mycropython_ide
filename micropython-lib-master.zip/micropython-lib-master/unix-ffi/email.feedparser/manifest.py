metadata(version="0.5.1")

require("re", unix_ffi=True)
require("email.errors", unix_ffi=True)
require("email.message", unix_ffi=True)
require("email.internal", unix_ffi=True)

package("email")
