metadata(
    description="MicroPython FFI helper module to easily interface with underlying shared libraries",
    version="0.1.3",
)

# Originally written by Damien George.

module("ffilib.py")
