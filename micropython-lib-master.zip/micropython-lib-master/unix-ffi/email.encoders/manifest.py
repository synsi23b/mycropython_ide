metadata(version="0.5.1")

require("base64")
require("binascii")
require("quopri")
require("re", unix_ffi=True)
require("string")

package("email")
