metadata(version="3.3.3-1")

require("os", unix_ffi=True)

module("getopt.py")
