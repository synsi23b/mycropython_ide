metadata(version="0.5.2")

# Originally written by Paul Sokolovsky.

module("socket.py")
