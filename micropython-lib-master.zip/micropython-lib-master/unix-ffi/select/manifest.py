metadata(version="0.3")

# Originally written by Paul Sokolovsky.

require("os", unix_ffi=True)
require("ffilib", unix_ffi=True)

module("select.py")
