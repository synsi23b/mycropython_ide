metadata(version="1.0.1")

module("tty.py")
