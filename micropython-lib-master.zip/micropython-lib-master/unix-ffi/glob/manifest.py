metadata(version="0.5.2")

require("os", unix_ffi=True)
require("os.path")
require("re", unix_ffi=True)
require("fnmatch")

module("glob.py")
