metadata(version="0.3.2")

# Originally written by Paul Sokolovsky.

require("ffilib", unix_ffi=True)

module("signal.py")
