metadata(version="0.1.2")

# Originally written by Paul Sokolovsky.

require("os", unix_ffi=True)
require("tty", unix_ffi=True)
require("select", unix_ffi=True)

package("ucurses")
