metadata(version="0.2.4")

# Originally written by Paul Sokolovsky.

require("ffilib", unix_ffi=True)

module("sqlite3.py")
