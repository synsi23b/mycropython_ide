metadata(version="0.5.2")

require("re", unix_ffi=True)
require("collections")
require("collections.defaultdict")

package("urllib")
