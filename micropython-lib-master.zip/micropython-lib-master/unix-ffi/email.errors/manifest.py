metadata(version="0.5.1")

package("email")
