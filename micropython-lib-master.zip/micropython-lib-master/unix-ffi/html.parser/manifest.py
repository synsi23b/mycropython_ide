metadata(version="3.3.3-2")

require("_markupbase", unix_ffi=True)
require("warnings")
require("html.entities", unix_ffi=True)
require("re", unix_ffi=True)

package("html")
