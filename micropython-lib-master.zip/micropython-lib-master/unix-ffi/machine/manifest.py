metadata(version="0.2.1")

# Originally written by Paul Sokolovsky.

require("ffilib", unix_ffi=True)
require("os", unix_ffi=True)
require("signal", unix_ffi=True)

package("machine")
