metadata(version="0.0.4")

# Originally written by Paul Sokolovsky.

require("ffilib", unix_ffi=True)

module("fcntl.py")
