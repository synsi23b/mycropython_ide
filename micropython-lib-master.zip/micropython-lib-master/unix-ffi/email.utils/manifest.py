metadata(version="3.3.3-2")

require("os", unix_ffi=True)
require("re", unix_ffi=True)
require("base64")
require("random")
require("datetime")
require("urllib.parse", unix_ffi=True)
require("warnings")
require("quopri")
require("email.charset", unix_ffi=True)

package("email")
