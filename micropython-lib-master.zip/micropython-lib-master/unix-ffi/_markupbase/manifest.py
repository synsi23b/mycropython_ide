metadata(version="3.3.3-1")

require("re", unix_ffi=True)

module("_markupbase.py")
