metadata(version="0.5.1")

require("email.parser", unix_ffi=True)
require("email.message", unix_ffi=True)
require("socket", unix_ffi=True)
require("collections")
require("urllib.parse", unix_ffi=True)
require("warnings")

package("http")
