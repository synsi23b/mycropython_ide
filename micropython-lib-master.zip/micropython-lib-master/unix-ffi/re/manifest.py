metadata(version="0.2.5")

# Originally written by Paul Sokolovsky.

require("ffilib", unix_ffi=True)

module("re.py")
