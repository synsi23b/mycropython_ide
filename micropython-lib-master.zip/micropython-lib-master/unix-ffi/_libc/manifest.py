metadata(
    description="MicroPython FFI helper module (deprecated, replaced by micropython-ffilib).",
    version="0.3.1",
)

# Originally written by Paul Sokolovsky.

module("_libc.py")
