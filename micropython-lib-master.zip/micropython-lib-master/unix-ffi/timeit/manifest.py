metadata(version="3.3.3-3")

require("getopt", unix_ffi=True)
require("itertools")
# require("linecache") TODO
require("time", unix_ffi=True)
require("traceback")

module("timeit.py")
