metadata(version="0.5.2")

require("re", unix_ffi=True)
require("binascii")
require("email.encoders", unix_ffi=True)
require("email.errors", unix_ffi=True)
require("email.charset", unix_ffi=True)

package("email")
